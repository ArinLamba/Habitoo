"use client";

import { cn } from "@/lib/utils";

import { usehabitViewLayoutStore } from "@/store/use-habit-layout-store";
import { useHabits } from "@/hooks/queries/use-habits";
import { useCompletions } from "@/hooks/queries/use-completions";
import { useStats } from "@/hooks/use-stats";
import { useTodayRollover } from "@/hooks/use-today-rollover";

import { HabitGridView } from "./grid-view/habit-grid-view";
import { BottomActionBar } from "./bottom-action-bar";

import { EmptyState } from "@/components/empty";

import { Loading } from "@/components/loading";
import { HabitListView } from "./list-view/habit-list-view";

export const HabitsClient = () => {
  const { habitViewLayout } = usehabitViewLayoutStore();

  useTodayRollover();

  const { data: habits = [], isLoading: isHabitsLoading } = useHabits();
  const { data: completions = [], isLoading: isCompletionsLoading } =
    useCompletions();

  const activeHabits = habits.filter(
    (habit) => habit.lifecycle === "active"
  );

  // Hook MUST remain before any early return
  const { statusMap, habitStatsMap } = useStats(
    activeHabits,
    completions
  );

  const isLoading = isHabitsLoading || isCompletionsLoading;
  const hasHabits = habits.length > 0;



  // ─────────────────────────────────────────────
  // Content
  // ─────────────────────────────────────────────

  return (
    <div className="flex h-[calc(100vh-45px)] flex-col gap-2">
      <div
        className={cn(
          "flex flex-1 flex-col overflow-x-hidden rounded-md",
          "bg-white/95 shadow-sm backdrop-blur",
          "scrollbar scrollbar-w-1.5 scrollbar-thumb-rounded scrollbar-thumb-zinc-300",
          "dark:bg-zinc-950/80 dark:scrollbar-thumb-zinc-700",
          habitViewLayout === "grid" &&
            "border border-black/10 dark:border-white/10"
        )}
      >
        {isLoading ? (
          <Loading />
        ) : !hasHabits ? (
          <EmptyState />
        ) : habitViewLayout === "grid" ? (
          <HabitGridView
            habits={habits}
            completions={completions}
            statusMap={statusMap}
            habitStatsMap={habitStatsMap}
          />
        ) : (
          <HabitListView
            habits={habits}
            completions={completions}
          />
        )}
      </div>

      {habitViewLayout === "grid" && (
        <BottomActionBar statusMap={statusMap} />
      )}
    </div>
  );
};