import { Menu } from "lucide-react"

import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet"
import { Sidebar } from "@/components/layout/sidebar"
import { DialogTitle } from "@radix-ui/react-dialog"

export const MobileLeftSidebar = () => {
	return (
		<Sheet >
			<SheetTrigger>
				<Menu className="dark:text-white block xl:hidden w-auto px-2" size={16}/>
				<DialogTitle />
			</SheetTrigger>
			<SheetContent className="p-0 z-100 overflow-visible" side="left">
				<Sidebar className="h-full w-full border-r-0"/>
			</SheetContent>
		</Sheet>
	)
}


