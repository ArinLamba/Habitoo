type Props = {
  children: React.ReactNode;
};

export const FeedWrapper = ({ children }: Props) => {
  return (
    <div className="flex-1 min-w-0 relative top-0 pb-0">
			{children}
    </div>
  );
};